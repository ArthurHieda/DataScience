--4
select min(salary) as "Salario Mínimo",
       max(salary) as "Salario Máximo",
       sum(salary) as "Soma Salários",
       round(avg(salary),2) as "Média Salarial"
from employees;
--5
select job_id, round(max(salary)) as "Maior Salário",
               round(min(salary)) as "Menor Salário",
               sum(salary) as "Soma Salários",
               round(avg(salary),2) as "Média Salarial"
from employees
group by job_id ;

desc employees;
--6
select department_name,job_id,count(last_name)
from employees e join departments d
on d.department_id = e.department_id
group by department_name,job_id
order by 1;

select job_id,count(*)
from employees
group by job_id;

--7
select count(distinct manager_id)
from employees;

--8
select max(Salary) - min(salary) DIFFERENCE
from employees;

--9
select w.manager_id, min(w.salary)
from employees b join employees w
on b.employee_id = w.manager_id
group by w.manager_id
having min(w.salary) >= 6000
order by 1;

select manager_id,min(salary)
from employees
where manager_id is not null
group by manager_id
having min(salary) >= 6000
order by 2 desc;